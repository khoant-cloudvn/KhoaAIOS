from app.repository import MemoryRepository
from app.domain import TaskState
def test_approval_and_audit():
    r=MemoryRepository(); t=r.create_task("x","y"); r.move(t.id,TaskState.WAITING_APPROVAL); a=r.create_approval(t.id); r.decide(a.id,True,"ok")
    assert r.approvals[a.id].status=="APPROVED"; assert len(r.audit_for(t.id))==4
