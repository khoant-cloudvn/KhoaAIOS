import os
from fastapi import FastAPI, HTTPException
from .agents import MockAgent
from .domain import TaskState
from .repository import MemoryRepository
from .schemas import ApprovalDecision, TaskCreate, TaskView

app = FastAPI(title="KHOA AI OS MVP Local Mock", version="0.2.0")
repo = MemoryRepository(); agent = MockAgent()
def view(t): return TaskView(id=t.id,title=t.title,description=t.description,state=t.state,requires_approval=t.requires_approval,result=t.result)
@app.get("/health")
def health(): return {"status":"ok","service":"khoa-ai-os","persistence":"memory" if os.getenv("DATABASE_URL") is None else "postgresql"}
@app.get("/api/v1/agents")
def agents(): return [{"name":agent.name,"mode":"mock","capabilities":["knowledge_processing"]}]
@app.post("/api/v1/tasks", response_model=TaskView, status_code=201)
def create_task(body: TaskCreate):
    t=repo.create_task(body.title,body.description,body.requires_approval)
    if body.requires_approval: repo.move(t.id,TaskState.WAITING_APPROVAL); repo.create_approval(t.id)
    return view(t)
@app.get("/api/v1/tasks/{task_id}", response_model=TaskView)
def get_task(task_id):
    t=repo.get_task(task_id)
    if not t: raise HTTPException(404,"task not found")
    return view(t)
@app.post("/api/v1/tasks/{task_id}/run", response_model=TaskView)
def run_task(task_id):
    t=repo.get_task(task_id)
    if not t: raise HTTPException(404,"task not found")
    if t.state == TaskState.WAITING_APPROVAL: raise HTTPException(409,"approval required")
    if t.state not in (TaskState.PENDING,TaskState.FAILED): raise HTTPException(409,"task cannot run")
    repo.move(task_id,TaskState.RUNNING)
    try: t.result=agent.execute(t.title,t.description); repo.move(task_id,TaskState.COMPLETED)
    except Exception as exc: repo.move(task_id,TaskState.FAILED); repo.log(task_id,"task.failed",str(exc)); raise
    return view(t)
@app.get("/api/v1/approvals")
def approvals(): return [a.__dict__ for a in repo.approvals_for()]
@app.post("/api/v1/approvals/{approval_id}/decision")
def decide(approval_id: str, body: ApprovalDecision):
    a=repo.approvals.get(approval_id)
    if not a: raise HTTPException(404,"approval not found")
    if a.status != "PENDING": raise HTTPException(409,"approval already decided")
    repo.decide(approval_id,body.approved,body.reason)
    repo.move(a.task_id,TaskState.PENDING if body.approved else TaskState.REJECTED)
    return a.__dict__
@app.get("/api/v1/tasks/{task_id}/audit")
def audit(task_id):
    if not repo.get_task(task_id): raise HTTPException(404,"task not found")
    return [x.__dict__ for x in repo.audit_for(task_id)]
