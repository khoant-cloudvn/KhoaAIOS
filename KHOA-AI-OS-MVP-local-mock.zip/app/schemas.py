from pydantic import BaseModel, Field
from .domain import TaskState
class TaskCreate(BaseModel): title: str = Field(min_length=1, max_length=200); description: str = ""; requires_approval: bool = True
class TaskView(BaseModel): id: str; title: str; description: str; state: TaskState; requires_approval: bool; result: str | None = None
class ApprovalDecision(BaseModel): approved: bool; reason: str = ""
