"""KHOA AI OS application package."""
