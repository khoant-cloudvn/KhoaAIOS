# KHOA AI OS — MVP Local Mock

Executable local mock of the KHOA AI OS workflow. It preserves the intended MVP boundaries: FastAPI HTTP API, PostgreSQL persistence, Redis/Celery worker configuration, Alembic migrations, explicit task state transitions, approval gates, audit events, and mock agent adapters.

## Quick start

```bash
docker compose up --build
curl http://localhost:8000/health
```

Create a task, approve it, and run the mock workflow:

```bash
curl -X POST http://localhost:8000/api/v1/tasks -H "content-type: application/json" -d '{"title":"Index knowledge","description":"Mock document workflow","requires_approval":true}'
curl http://localhost:8000/api/v1/approvals
curl -X POST http://localhost:8000/api/v1/approvals/<approval_id>/decision -H "content-type: application/json" -d '{"approved":true,"reason":"Approved for local test"}'
curl -X POST http://localhost:8000/api/v1/tasks/<task_id>/run
```

The API defaults to an in-memory repository when imported without a database, which makes unit tests and local inspection simple. Docker uses PostgreSQL and the included Alembic migration. `docker-compose.yml` also starts Redis and a Celery worker; the mock workflow endpoint executes synchronously so the end-to-end path remains deterministic.

## Test status

Run `pytest -q`. Tests that require FastAPI are collected when dependencies are installed from `requirements.txt`. Docker/PostgreSQL/Redis integration is not run automatically in this delivery environment; run `docker compose up --build` followed by `pytest -q tests/test_e2e_mock_workflow.py` to validate that path.

## Layout

* `app/` — API, domain state machine, repositories, adapters, and Celery task.
* `alembic/` — migration environment and initial schema migration.
* `tests/` — unit, integration, and end-to-end mock workflow tests.
* `docs/` — implementation notes and API/workflow contract.

This is a local mock, not a production security boundary. Authentication, secret management, external tool connectors, and real agent execution are intentionally out of scope.
