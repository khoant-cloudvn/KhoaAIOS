# Implementation notes

The state machine deliberately rejects illegal transitions. Approval decisions are audited and an approved task becomes runnable; rejection is terminal. The mock agent produces deterministic output without API keys.

The API layer currently uses an in-memory repository so the local mock can be exercised without external services. The SQLAlchemy models and Alembic migration define the PostgreSQL schema used by the Compose deployment. A follow-up production slice should replace the repository wiring with a request-scoped SQLAlchemy session and add authentication/idempotency keys.
