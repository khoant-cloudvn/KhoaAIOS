class MockAgent:
    name = "mock-agent"
    def execute(self, title: str, description: str) -> str:
        return f"mock-completed:{title}:{len(description)}-chars"
