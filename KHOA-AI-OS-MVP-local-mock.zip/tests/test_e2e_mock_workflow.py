import pytest
pytest.importorskip("fastapi")
from fastapi.testclient import TestClient
from app.main import app, repo
def test_end_to_end_mock_workflow():
    repo.tasks.clear(); repo.approvals.clear(); repo.audit.clear(); c=TestClient(app)
    created=c.post("/api/v1/tasks",json={"title":"index","description":"doc","requires_approval":True}); assert created.status_code==201
    task=created.json(); assert task["state"]=="WAITING_APPROVAL"
    approval=c.get("/api/v1/approvals").json()[0]
    assert c.post(f"/api/v1/tasks/{task['id']}/run").status_code==409
    assert c.post(f"/api/v1/approvals/{approval['id']}/decision",json={"approved":True,"reason":"go"}).status_code==200
    result=c.post(f"/api/v1/tasks/{task['id']}/run"); assert result.status_code==200; assert result.json()["state"]=="COMPLETED"
