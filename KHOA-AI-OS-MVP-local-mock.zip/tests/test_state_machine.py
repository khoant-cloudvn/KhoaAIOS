from app.domain import TaskState, transition
import pytest
def test_valid_transitions(): assert transition(TaskState.PENDING,TaskState.RUNNING)==TaskState.RUNNING
def test_invalid_transition():
    with pytest.raises(ValueError): transition(TaskState.COMPLETED,TaskState.RUNNING)
