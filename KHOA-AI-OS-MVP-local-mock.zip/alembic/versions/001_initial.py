"""initial task, approval, audit schema"""
from alembic import op
import sqlalchemy as sa
revision="001_initial"; down_revision=None; branch_labels=None; depends_on=None
def upgrade():
    op.create_table("tasks",sa.Column("id",sa.String(36),primary_key=True),sa.Column("title",sa.String(200),nullable=False),sa.Column("description",sa.Text(),nullable=False),sa.Column("state",sa.String(32),nullable=False),sa.Column("requires_approval",sa.Boolean(),nullable=False),sa.Column("result",sa.Text()),sa.Column("created_at",sa.DateTime(timezone=True)))
    op.create_table("approvals",sa.Column("id",sa.String(36),primary_key=True),sa.Column("task_id",sa.String(36),sa.ForeignKey("tasks.id"),nullable=False),sa.Column("status",sa.String(16),nullable=False),sa.Column("reason",sa.Text(),nullable=False),sa.Column("created_at",sa.DateTime(timezone=True)))
    op.create_table("audit_events",sa.Column("id",sa.String(36),primary_key=True),sa.Column("task_id",sa.String(36),nullable=False),sa.Column("action",sa.String(100),nullable=False),sa.Column("detail",sa.Text(),nullable=False),sa.Column("created_at",sa.DateTime(timezone=True)))
def downgrade():
    op.drop_table("audit_events"); op.drop_table("approvals"); op.drop_table("tasks")
