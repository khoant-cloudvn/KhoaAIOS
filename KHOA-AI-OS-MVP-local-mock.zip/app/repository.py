from dataclasses import dataclass, field
from uuid import uuid4
from .domain import TaskState, transition

@dataclass
class TaskRecord:
    id: str; title: str; description: str; state: TaskState; requires_approval: bool; result: str | None = None
@dataclass
class ApprovalRecord:
    id: str; task_id: str; status: str = "PENDING"; reason: str = ""
@dataclass
class AuditRecord:
    id: str; task_id: str; action: str; detail: str = ""
class MemoryRepository:
    def __init__(self): self.tasks={}; self.approvals={}; self.audit=[]
    def create_task(self, title, description, requires_approval=True):
        t=TaskRecord(str(uuid4()), title, description, TaskState.PENDING, requires_approval); self.tasks[t.id]=t
        self.log(t.id,"task.created",title); return t
    def get_task(self, task_id): return self.tasks.get(task_id)
    def move(self, task_id, target):
        t=self.tasks[task_id]; t.state=transition(t.state,target); self.log(task_id,"task.state_changed",target.value); return t
    def create_approval(self, task_id):
        a=ApprovalRecord(str(uuid4()),task_id); self.approvals[a.id]=a; self.log(task_id,"approval.requested",a.id); return a
    def approvals_for(self, task_id=None): return [a for a in self.approvals.values() if task_id is None or a.task_id==task_id]
    def decide(self, approval_id, approved, reason):
        a=self.approvals[approval_id]; a.status="APPROVED" if approved else "REJECTED"; a.reason=reason; self.log(a.task_id,"approval.decided",a.status); return a
    def log(self, task_id, action, detail=""): self.audit.append(AuditRecord(str(uuid4()),task_id,action,detail))
    def audit_for(self, task_id): return [x for x in self.audit if x.task_id==task_id]
