from celery import Celery
import os
celery_app = Celery("khoa", broker=os.getenv("REDIS_URL","redis://localhost:6379/0"), backend=os.getenv("REDIS_URL","redis://localhost:6379/0"))
@celery_app.task(name="khoa.mock_task")
def mock_task(title, description): return {"status":"completed","result":f"mock-completed:{title}:{len(description)}-chars"}
