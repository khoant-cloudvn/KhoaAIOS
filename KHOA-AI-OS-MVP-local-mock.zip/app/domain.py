from enum import Enum

class TaskState(str, Enum):
    PENDING = "PENDING"
    WAITING_APPROVAL = "WAITING_APPROVAL"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"

ALLOWED = {
    TaskState.PENDING: {TaskState.WAITING_APPROVAL, TaskState.RUNNING, TaskState.CANCELLED},
    TaskState.WAITING_APPROVAL: {TaskState.PENDING, TaskState.RUNNING, TaskState.REJECTED, TaskState.CANCELLED},
    TaskState.RUNNING: {TaskState.COMPLETED, TaskState.FAILED, TaskState.CANCELLED},
    TaskState.FAILED: {TaskState.RUNNING, TaskState.CANCELLED},
    TaskState.COMPLETED: set(), TaskState.REJECTED: set(), TaskState.CANCELLED: set(),
}

def transition(current: TaskState, target: TaskState) -> TaskState:
    if target not in ALLOWED[current]:
        raise ValueError(f"invalid transition: {current} -> {target}")
    return target
